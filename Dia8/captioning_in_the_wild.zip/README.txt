The dataset is described in the following paper:

"Captioning in the Wild: How People Caption Images on Flickr"
Philipp Blandfort, Tushar Karayil, Damian Borth, Andreas Dengel
Multimodal Understanding of Social, Affective and Subjective Attributes, An ACM MM'17 Workshop, 2017

If you use the dataset for research, please cite our paper.
